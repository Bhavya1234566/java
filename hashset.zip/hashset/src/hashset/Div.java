package hashset;

import java.util.HashSet;

public class Div {
	HashSet<String> set=new HashSet<String>(); 
	public void process(){
		set.add("ram");
		set.add("preet");
		set.add("ram");
		System.out.println(set);
	}
	
	

}
