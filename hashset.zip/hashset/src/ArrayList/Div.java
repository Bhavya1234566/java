package ArrayList;

import java.util.ArrayList;

public class Div {
	ArrayList<String> list=new ArrayList<String>();
	public void process(){
		list.add("hello");
		list.add("sham");
		list.add("hello");
		System.out.println(list);
	}

}
