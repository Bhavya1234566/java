package ArrayList;

public class Test {
	public static void main(String[] args) {
		Div div=new Div();
		div.process();
	}

}
