package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ProductDao {
	int p;

	public void ShowList() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/product1","root","root");  
			Statement stmt=con.createStatement(); 
		
			
			ResultSet rs=stmt.executeQuery("select * from items");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
			}

	public int getPrice(int id) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/product1","root","root");  
			Statement stmt=con.createStatement(); 
		
			
			ResultSet rs=stmt.executeQuery("select * from items where pid='"+id+"'");
			if(rs.next())  
				p=rs.getInt(3);
			  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
			
		return p;
	}
	
		
	
	

}
