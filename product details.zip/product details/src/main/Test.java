package main;

import Controller.UserController;

public class Test {
	public static void main(String[] args) {
		UserController uc=new UserController();
		uc.ShowList();
	}
	

}
