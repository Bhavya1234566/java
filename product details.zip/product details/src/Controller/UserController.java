package Controller;

import java.util.Scanner;

import Bean.Users;

import Dao.UserDao;

public class UserController {
	int id,p,qty,tp,price;
	String name;
	Scanner sc=new Scanner(System.in);
	public void ShowList(){
		ProductController pc=new ProductController();
		pc.process();
		System.out.println("enter id:");
		id=sc.nextInt();
		p=pc.getPrice(id);
		System.out.println(p);
		System.out.println("enter qty:");
		qty=sc.nextInt();
		tp=qty*p;
		System.out.println("price is:"+tp);
		System.out.println("enter id,name,bill");
		id=sc.nextInt();
		name=sc.next();
		price=sc.nextInt();
		Users users=new Users();
		users.setId(id);
		users.setName(name);
		users.setPrice(price);
		UserDao dao=new UserDao();
		dao.Bill(users);
	}

}
