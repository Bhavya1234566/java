package Controller;

import Dao.ProductDao;

public class ProductController {
	int i;

	public void process() {
		ProductDao pd=new ProductDao();
		pd.ShowList();
		
	}

	public int getPrice(int id) {
		
		ProductDao dao=new ProductDao();
		i=dao.getPrice(id);
		return i;
	}

}
