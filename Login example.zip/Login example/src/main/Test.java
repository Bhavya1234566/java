package main;

import controller.LoginController;

public class Test {
	public static void main(String[] args) {
		LoginController controller=new LoginController();
		controller.process();
	}

}
