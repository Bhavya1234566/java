package dao;

import bean.Login;

public class Logindao {
	int f=0;
	public int process(Login login){
		if(login.getId()==1 && login.getPwd().equals("ram")){
			f=1;
		}
		else{
			f=0;
		}
		return f;
	}

}
