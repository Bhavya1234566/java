package controller;

import java.util.Scanner;

import bean.Login;
import dao.Logindao;

public class LoginController {
	Scanner sc=new Scanner(System.in);
	private int id;
	private String pwd;
	public void process(){
		System.out.println("enter id&pwd");
		id=sc.nextInt();
		pwd=sc.next();
		Login login=new Login();
		login.setId(id);
		login.setPwd(pwd);
		Logindao ld=new Logindao();
		int f=ld.process(login);
		if(f==1){
			System.out.println("succes");
		}
		else{
			System.out.println("fail");
		}
	}

}
