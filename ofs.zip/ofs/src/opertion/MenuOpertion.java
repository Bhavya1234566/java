package opertion;

import java.util.Scanner;

public class MenuOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process(){
		System.out.println("press 1 for product/n press 2 for show user/n enter choice ");
		ch=sc.nextInt();
		if(ch==1)
		{
			ProductOpertion opertion=new ProductOpertion();
			opertion.process();
		}
		else if(ch==2){
			ProductOpertion opertion=new ProductOpertion();
			opertion.showuser();
		}
		else{
			System.out.println("wrong");
		}
	}

}
