package opertion;

import java.util.Scanner;

import controller.UserController;

public class UserOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);

	public void process() {
		System.out.println("press 1 for registration /n press 2 for login/n press 3 for forgetpwd/n enter choice");
		ch=sc.nextInt();
		if(ch==1){
			UserController controller=new UserController();
			controller.registration();
		}
		else if(ch==2){
			UserController controller=new UserController();
			controller.login();
			
		}
		else if(ch==3){
			UserController controller= new UserController();
			controller.forgetpwd();
		}
	}

}
