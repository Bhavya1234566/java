package opertion;

import java.util.Scanner;

import controller.ProductController;

public class ProductOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process(){
		System.out.println("press 1 for add product/n press 2 for delete product/n press 3 for update product/n press 4 for show/n enter choice");
		ch=sc.nextInt();
		if(ch==1){
			ProductController controller=new ProductController();
			controller.addproduct();
		}
		else if(ch==2){
			ProductController controller=new ProductController();
			controller.deleteproduct();
		}
		else if(ch==3){
			ProductController controller=new ProductController();
			controller.updateproduct();
		}
		else if(ch==4){
			ProductController controller=new ProductController();
			controller.showproduct();
		}
	}
	public void showuser() {
		ProductController controller=new ProductController();
		controller.showuser();
		
	}
}
