package controller;

import java.util.Scanner;

import bean.Product;
import dao.ProductDao;

public class ProductController {
	int id,price;
	String name;
	Scanner sc=new Scanner(System.in);
	public void addproduct(){
		System.out.println("enter id,name,price");
		id=sc.nextInt();
		name=sc.next();
		price=sc.nextInt();
		Product product=new Product();
		product.setId(id);
		product.setName(name);
		product.setPrice(price);
		ProductDao dao=new ProductDao();
		dao.addproduct(product);
	}
	public void deleteproduct(){
		System.out.println("enter id");
		id=sc.nextInt();
		Product product=new Product();
		product.setId(id);
		ProductDao dao=new ProductDao();
		dao.deleteproduct(product);
	}
	public void updateproduct() {
		System.out.println("enter id");
		id=sc.nextInt();
		name=sc.next();
		Product product=new Product();
		product.setId(id);
		product.setName(name);
		ProductDao dao=new ProductDao();
		dao.updateproduct(product);
	}
	public void showproduct() {
		System.out.println("enter id");
		id=sc.nextInt();
		Product product=new Product();
		product.setId(id);
		ProductDao dao=new ProductDao();
		dao.showproduct(product);
		
	}
	public void showuser() {
		ProductDao dao=new ProductDao();
		dao.showuser();	
		
	}
	public void show(){
		Product product=new Product();
		product.setId(id);
		ProductDao dao=new ProductDao();
		dao.show(product);
	}

}
