package controller;

import java.util.Scanner;

import bean.Admin;
import dao.AdminDao;
import opertion.MenuOpertion;

public class AdminController {
	int id,passward;
	boolean b;
	Scanner sc=new Scanner(System.in);
	public void login(){
		System.out.println("enter id&passward");
		id=sc.nextInt();
		passward=sc.nextInt();
		Admin admin=new Admin();
		admin.setId(id);
		admin.setPassward(passward);
		AdminDao dao=new AdminDao();
	 b=	dao.login(admin);
		if(b){
			System.out.println("write");
			MenuOpertion menuOpertion=new MenuOpertion();
			menuOpertion.process();
		}
		else{
			System.out.println("wrong");
		}
	}

}
