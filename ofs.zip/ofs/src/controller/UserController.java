package controller;

import java.util.Scanner;

import bean.Bill;
import bean.Product;
import bean.User;
import dao.BillDao;
import dao.GetPrice;
import dao.UserDao;

public class UserController {
	int id,passward,price,qty,bill;
	String name,email;
	Scanner sc=new Scanner(System.in);
	public void registration() {
		System.out.println("enter id&name&email&pwd");
		id=sc.nextInt();
		name=sc.next();
		email=sc.next();
		passward=sc.nextInt();
		User user=new User();
		user.setId(id);
		user.setName(name);
		user.setEmail(email);
		user.setPassward(passward);
		UserDao dao=new UserDao();
		dao.registration(user);	
		
	}
	public void login() {
		System.out.println("enter email&pwd");
		email=sc.next();
		passward=sc.nextInt();
		User user=new User();
		user.setEmail(email);
		user.setPassward(passward);
		UserDao dao=new UserDao();
		boolean b=dao.login(user);
		if(b){
			ProductController controller=new ProductController();
			controller.show();
			System.out.println("enter id of item");
			id=sc.nextInt();
			GetPrice getPrice=new GetPrice();
			price=getPrice.pd(id);
			System.out.println("enter qty");
			qty=sc.nextInt();
			bill=qty*price;
			System.out.println("total price is"+bill);
			System.out.println("enter email");
			email=sc.next();
			System.out.println("enter id & email&price");
			id=sc.nextInt();
			email=sc.next();
			bill=sc.nextInt();
			Bill b1=new Bill();
			b1.setId(id);
			b1.setEmail(email);
			b1.setBill(bill);
			BillDao billDao=new BillDao();
			billDao.db(b1);
			
			
		}
		
	}
	public void forgetpwd() {
		System.out.println("enter email");
		email=sc.next();
		
		User user=new User();
		user.setEmail(email);
		
		UserDao dao=new UserDao();
		dao.forgetpwd(user);	
		
	}

}
