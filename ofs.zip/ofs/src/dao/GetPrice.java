package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class GetPrice {
	int price;
	Scanner sc=new Scanner(System.in);
	public int pd(int id){
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			ResultSet rs=stmt.executeQuery("select * from product where id='"+id+"'");  
			if(rs.next())  
			System.out.println("price is"+rs.getInt(3)); 
			price=rs.getInt(3);
			
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
		return price;
	}
	

}
