package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import bean.User;
import controller.UserController;

public class UserDao {
	int i,ch;
	boolean b=false;
	Scanner sc=new Scanner(System.in);
	public void registration(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			i=stmt.executeUpdate("insert into user values('"+user.getId()+"','"+user.getName()+"','"+user.getEmail()+"','"+user.getPassward()+"') ");
			
			ResultSet rs=stmt.executeQuery("select * from user");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
	}

	public boolean login(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from user where email='"+user.getEmail()+"'and passward='"+user.getPassward()+"'"); 
			
				if(rs.next())  
				{b=true;
					System.out.println("login successfully");  
				}
				else{
					b=false;
					System.out.println("press 1 for registration /n press 2 for forgetpwd/n enter choice");
					ch=sc.nextInt();
					if(ch==1){
						UserController controller=new UserController();
						controller.registration();
					}
					else if(ch==2){
						UserController controller=new UserController();
						controller.forgetpwd();
					}
				}
					con.close(); 
			
			 
			}catch(Exception e){ System.out.println(e);}  
		return b;
		
	}

	public void forgetpwd(User user) {
		
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			
			
			ResultSet rs=stmt.executeQuery("select * from user where email='"+user.getEmail()+"'");  
			while(rs.next())  
			System.out.println("passward is:"+rs.getInt(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
	}
	

}
