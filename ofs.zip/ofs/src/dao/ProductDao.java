package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Product;

public class ProductDao {int i;

	public void addproduct(Product product) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			i=stmt.executeUpdate("insert into product values('"+product.getId()+"','"+product.getName()+"','"+product.getPrice()+"') ");
			
			ResultSet rs=stmt.executeQuery("select * from product");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
		
		
	}

	public void deleteproduct(Product product) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			i=stmt.executeUpdate("delete * product where id='"+product.getId()+"'");
			
			ResultSet rs=stmt.executeQuery("select * from product");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
		
	}

	public void updateproduct(Product product) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			i=stmt.executeUpdate("udpate product set where id='"+product.getId()+"',name='"+product.getName()+"'");
			
			ResultSet rs=stmt.executeQuery("select * from product");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
	}

	public void showproduct(Product product) {
		
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			ResultSet rs=stmt.executeQuery("select * from product");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
	}

	public void showuser() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			
			ResultSet rs=stmt.executeQuery("select * from user");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
		
	}

	public void show(Product product) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ofs","root","root");  
			Statement stmt=con.createStatement(); 
			
			
			ResultSet rs=stmt.executeQuery("select * from product");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
	}

}
