package main;

import opertion.Choiceopertion;

public class Test {
public static void main(String[] args) {
	Choiceopertion choiceopertion=new Choiceopertion();
	choiceopertion.process();
}
}
