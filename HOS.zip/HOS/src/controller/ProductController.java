package controller;

import java.util.Scanner;

import bean.Product;
import dao.BillDao;
import dao.GetPrice;
import dao.ProductDao;

public class ProductController {
	int id,price,qty,tp=0;
	String name;
	Scanner sc=new Scanner(System.in);
	public void process(){
		
		
		ProductDao dao=new ProductDao();
		dao.process();
		GetPrice getPrice=new GetPrice();
		int p=getPrice.bill();
		System.out.println("enter qty:");
		qty=sc.nextInt();
		tp=qty*p;
		System.out.println("total price is:"+tp);
		BillController controller=new BillController();
		controller.process();
	}
}
