package controller;

import java.util.Scanner;

import bean.Bill;
import dao.BillDao;

public class BillController {
	int id,price;
	String name;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("enter id, name price");
		id=sc.nextInt();
		name=sc.next();
		price=sc.nextInt();
		Bill b=new Bill();
		b.setId(id);
		b.setName(name);
		b.setBill(price);
		BillDao billDao=new BillDao();
		billDao.bill(b);
		
		
	}

}
