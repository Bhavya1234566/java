package controller;

import java.util.Scanner;

import bean.User;
import dao.UserDao;

public class UserController {
	int id,pwd;
	String name,email;
	Scanner sc=new Scanner(System.in);
	public void register(){
		System.out.println("enter id & name & email & pwd:");
		id=sc.nextInt();
		name=sc.next();
		email=sc.next();
		pwd=sc.nextInt();
		User u=new User();
		u.setId(id);
		u.setName(name);
		u.setEmail(email);
		u.setPwd(pwd);
		UserDao ud=new UserDao();
		ud.register(u);
	}
	
	public void login() {
		System.out.println("enter email & pwd;");
		email=sc.next();
		pwd=sc.nextInt();
		User u=new User();
		u.setEmail(email);
		u.setPwd(pwd);
		UserDao dao=new UserDao();
		boolean b=dao.login(u);
		if(b)
		{
			System.out.println("right");
			ProductController controller=new ProductController();
			controller.process();
			
		}
		else
		{
			System.out.println("w.p");
			ForgetPwd();
		}
		
		
	}

	public void ForgetPwd() {
		System.out.println("enter email:");
		email=sc.next();
		User u=new User();
		u.setEmail(email);
		UserDao dao=new UserDao();
		dao.ForgetPwd(u);
		
	}

	public void ChangePwd() {
		System.out.println("enter email:");
		email=sc.next();
		User u=new User();
		u.setEmail(email);
		UserDao dao=new UserDao();
		dao.ChangePwd(u);
		
	}
	

}
