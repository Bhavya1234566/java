package main;

import opertion.UserOpertion;

public class Test {
	public static void main(String[] args) {
		UserOpertion opertion=new UserOpertion();
		opertion.process();
	}

}
