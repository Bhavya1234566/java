package opertion;

import java.util.Scanner;

import controller.UserController;

public class UserOpertion {
	int ch,x;
	Scanner sc=new Scanner(System.in);
	public void process(){
		do{
		System.out.println("press 1 for registration/n press 2 for login/n press 3 for forget passward/n press 4 for change pwd/n enter choice:");
		ch=sc.nextInt();
		if(ch==1){
			UserController controller=new UserController();
			controller.register();
		}
		else if(ch==2){
			UserController controller=new UserController();
			controller.login();
		}
		else if(ch==3){
			UserController controller=new UserController();
			controller.ForgetPwd();
		}
		else if(ch==4){
			UserController controller=new UserController();
			controller.ChangePwd();
		}
		else{
			System.out.println("wrong");
		}
		System.out.println("do u want to contine:");
		x=sc.nextInt();
		}while(x==1);
	}

}
