package dao;
import java.sql.*;
import java.util.Scanner;

import bean.User;  

public class UserDao { 
	int i,id,pwd,p;
	String name,email;
	boolean b=false;
	Scanner sc=new Scanner(System.in);
	public void register(User user){
		
	try{  
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/registration","root","root");  
	Statement stmt=con.createStatement(); 
	
	i=stmt.executeUpdate("insert into user1 values('"+user.getId()+"','"+user.getName()+"','"+user.getPwd()+"',+'"+user.getEmail()+"') ");
	
	ResultSet rs=stmt.executeQuery("select * from user1");  
	while(rs.next())  
	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getString(4));  
	con.close();  
	}catch(Exception e){ System.out.println(e);}  
	}
	public boolean login(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/registration","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from user1 where email='"+user.getEmail()+"' and pwd='"+user.getPwd()+"'"); 
			
				if(rs.next())  
				{b=true;
					System.out.println("login successfully");  
				}
				else{
					b=false;
				}
					con.close(); 
			
			 
			}catch(Exception e){ System.out.println(e);}  
		return b;
			}
	public void ForgetPwd(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/registration","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from user1 where email='"+user.getEmail()+"'");  
			if(rs.next())  
			System.out.println("pwd is:"+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
			}
	public void ChangePwd(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/registration","root","root");  
			Statement stmt=con.createStatement(); 
			System.out.println("enter new pwd:");
			pwd=sc.nextInt();
			p= stmt.executeUpdate("update user1 set pwd='"+pwd+"' where email='"+user.getEmail()+"'");
			ResultSet rs=stmt.executeQuery("select * from user1");  
			while(rs.next())  
			System.out.println("pwd reset"+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
			}
		
	}
		
	
		
	     



