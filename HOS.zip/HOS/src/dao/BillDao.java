package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import bean.Bill;

public class BillDao {
	int i,id,price;
	String name;
	Scanner sc=new Scanner(System.in);
	public void bill(Bill bill){
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user_bill","root","root");  
			Statement stmt=con.createStatement(); 
		
			i=stmt.executeUpdate("insert into bill values('"+bill.getId()+"','"+bill.getName()+"','"+bill.getBill()+"')");
			ResultSet rs=stmt.executeQuery("select * from bill");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
			}
	

}
