package com;

import java.util.Scanner;

public class Kids {
	int ch,qty,x,kb;
	Scanner sc=new Scanner(System.in);
	public int process(){
		do{
		System.out.println("press 1 for toys\n press 2 for cloths\n enter choice:");
		ch=sc.nextInt();
		if(ch==1)
		{
			System.out.println("toys @ 100");
			System.out.println("enter qty:");
			qty=sc.nextInt()*100;
			System.out.println("total toys"+qty);
		}
		else if(ch==2){
			System.out.println("cloths @ 120");
			System.out.println("enter qty:");
			qty=sc.nextInt()*120;
			System.out.println("total cloths"+qty);
		}
		else{
			System.out.println("wrong");
		}
		System.out.println("press 1 for continue kid shop:");
		x=sc.nextInt();
		kb=qty+kb;
		}while(x==1);
		System.out.println(kb);
		return kb;
		
	}

}
