package com;

import java.util.Scanner;

public class Men {
	int ch,x,qty,mb;
	Scanner sc=new Scanner(System.in);
	public int process(){
		do{
		System.out.println("press 1 for shirt\n press 2 for pent\n enter choice:");
		ch=sc.nextInt();
		if(ch==1)
		{
			System.out.println("shirt @ 100");
			System.out.println("enter qty:");
			qty=sc.nextInt()*100;
			System.out.println("total shirt"+qty);
		}
		else if(ch==2){
			System.out.println("pent @ 120");
			System.out.println("enter qty:");
			qty=sc.nextInt()*120;
			System.out.println("total pent"+qty);
		}
		else{
			System.out.println("wrong");
		}
		
		System.out.println("press 1 for continue men shop:");
		x=sc.nextInt();
		mb=qty+mb;
		}while(x==1);
		System.out.println(mb);
		return mb;
		
	}

}
