package com;

import java.util.Scanner;

public class Women {
	int ch,qty,x,wb;
	Scanner sc=new Scanner(System.in);
	public int process(){
		do{
		System.out.println("press 1 for tshirt\n press 2 for jeans\n enter choice:");
		ch=sc.nextInt();
		if(ch==1)
		{
			System.out.println("tshirt @ 100");
			System.out.println("enter qty:");
			qty=sc.nextInt()*100;
			System.out.println("total tshirt"+qty);
		}
		else if(ch==2){
			System.out.println("jeans @ 120");
			System.out.println("enter qty:");
			qty=sc.nextInt()*120;
			System.out.println("total jeans"+qty);
		}
		else{
			System.out.println("wrong");
		}
		System.out.println("press 1 for continue women shop:");
		x=sc.nextInt();
		wb=qty+wb;
		}while(x==1);
		System.out.println(wb);
		return wb;
		
	}

}


