package com;

import java.util.Scanner;

public class Discount {
	int ch,m,w,k;
	double dis;
	Scanner sc=new Scanner(System.in);
	public int process(int m, int w, int k){
		System.out.println("press 1 for men bill\n press 2 for women bill\n press 3 for kids bill\npress 4 for men &women bill\n press 5 for women &kid\n press 6 for men &kid\n press 7 for three of all\n enter choice:");
		ch=sc.nextInt();
		switch(ch){
		case 1: if(m>500 && m<1000)
			{
				dis=m*0.2;
				System.out.println(dis);
				break;
			}
			else if(m>1000 && m<3000)
			{
				dis=m*0.3;
				System.out.println(dis);
				break;
			}
			else if(m>5000)
			{
				dis=m*0.5;
				System.out.println(dis);
				break;
			}
			else
			{
				System.out.println("wrong");
				break;
			}
		case 2:if(w>500 && w<1000)
			{
				dis=w*0.2;
				System.out.println(dis);
				break;
			}
			else if(w>1000 && w<3000)
			{
				dis=w*0.3;
				System.out.println(dis);
				break;
			}
			else if(w>5000)
			{
				dis=w*0.5;
				System.out.println(dis);
				break;
			}
			else
			{
				System.out.println("wrong");
				break;
			}

		case 3:if(k>500 && k<1000)
		{
			dis=k*0.2;
			System.out.println(dis);
			break;
		}
		else if(k>1000 && k<3000)
		{
			dis=k*0.3;
			System.out.println(dis);
			break;
		}
		else if(k>5000)
		{
			dis=k*0.5;
			System.out.println(dis);
			break;
		}
		else
		{
			System.out.println("wrong");
			break;
		}
		case 4:if(m+w>5000)
		{
			dis=m+w*0.5;
			System.out.println(dis);
			break;
		}
		case 5:if(w+k>5000)
		{
			dis=w+k*0.5;
			System.out.println(dis);
			break;
		}
		case 6:if(m+k>5000)
		{
			dis=m+k*0.5;
			System.out.println(dis);
			break;
		}
		case 7:if(m+w+k>5000)
		{
			dis=m+w+k*0.7;
			System.out.println(dis);
			break;
		}
	default:System.out.println("wrong");
		}
		return 0;
		
	}
}