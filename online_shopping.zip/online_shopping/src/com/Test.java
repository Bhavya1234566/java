package com;

public class Test {
	public static void main(String[] args) {
		Menu menu=new Menu();
		menu.show();
	}

}
