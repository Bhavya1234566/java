package com;

import java.util.Scanner;

public class Menu {
	int ch,bill,x,mbill,wbill,kbill,m,w,k,tp;
	int tb;
	Scanner sc=new Scanner(System.in);
	public int show(){
	do{
		System.out.println("press 1 for Men\n press 2 for women\n press 3 fo kids\n enter type:");
		ch=sc.nextInt();
		if(ch==1)
		{
			Men men=new Men();
			mbill=men.process();
			m=m+mbill;
		}
		else if(ch==2)
		{
			Women women=new Women();
			wbill=women.process();
			w=w+wbill;
			
		}
		else if(ch==3)
		{
			Kids kids=new Kids();
			kbill=kids.process();
			k=k+kbill;
			
		}
		
		System.out.println("press 1 for continue for shopping:");
		x=sc.nextInt();
		tp=m+w+k;
		System.out.println("total bill:"+tp);
		}while(x==1);
		Discount dis=new Discount();
		tb=dis.process(m,w,k);
		System.out.println(tb);
		return tb;
		
		
		
	}
	
}
