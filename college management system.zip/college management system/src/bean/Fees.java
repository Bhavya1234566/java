package bean;

public class Fees {
	private int fid,stid,cid,deposit,pending,total,after_pay;

	public int getAfter_pay() {
		return after_pay;
	}

	public void setAfter_pay(int after_pay) {
		this.after_pay = after_pay;
	}

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public int getStid() {
		return stid;
	}

	public int setStid(int stid) {
		return this.stid = stid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getDeposit() {
		return deposit;
	}

	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}

	public int getPending() {
		return pending;
	}

	public int setPending(int pending) {
		return this.pending = pending;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

}
