package bean;

public class DueFees {
	private int stid,duependingfees;

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public int getDuependingfees() {
		return duependingfees;
	}

	public void setDuependingfees(int duependingfees) {
		this.duependingfees = duependingfees;
	}

}
