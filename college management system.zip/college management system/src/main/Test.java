package main;

import opertion.MenuOperation;

public class Test {
	public static void main(String[] args) {
		MenuOperation menuOperation=new MenuOperation();
		menuOperation.process();
	}

}
