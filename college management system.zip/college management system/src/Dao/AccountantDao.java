package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Accountant;

public class AccountantDao {

	public void add(Accountant accountant) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("insert into accountant values(?,?,?,?)");
			ps.setInt(1,accountant.getAid());
			ps.setString(2,accountant.getAname());
			ps.setInt(3,accountant.getPwd());
			ps.setString(4,accountant.getEmail());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from accountant"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getString(4));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void delete(Accountant accountant) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("delete from accountant where aid=(?)");
			ps.setInt(1,accountant.getAid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from accountant"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getString(4));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void update(Accountant accountant) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("update accountant set aname=(?), pwd=(?),email=(?) where aid=(?)");
			ps.setString(1, accountant.getAname());
			ps.setInt(2, accountant.getPwd());
			ps.setString(3, accountant.getEmail());
			ps.setInt(4,accountant.getAid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from accountant"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getString(4));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
		
	}

	public void show() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from accountant");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getString(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
	}

	public boolean login(Accountant accountant) {
		boolean b=false;
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from accountant where aid='"+accountant.getAid()+"' and pwd='"+accountant.getPwd()+"' "); 
			
				if(rs.next())  
				{b=true;
					System.out.println("login successfully");  
				}
				else{
					b=false;
				}
					con.close(); 
			
			 
			}catch(Exception e){ System.out.println(e);}  
		return b;
		
	}

}
