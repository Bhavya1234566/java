package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Book;

public class BookDao {

	public void add(Book book) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("insert into book values(?,?,?,?)");
			ps.setInt(1,book.getBid());
			ps.setString(2,book.getBname());
			ps.setInt(3,book.getPrice());
			ps.setInt(4,book.getBqty());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from book"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getInt(4));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void delete(Book book) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("delete from book where bid=(?)");
			ps.setInt(1,book.getBid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from book"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getInt(4));  
			con.close();  
		
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void update(Book book) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("update book set bname=(?), price=(?),bqty=(?) where bid=(?)");
			ps.setString(1, book.getBname());
			ps.setInt(2, book.getPrice());
			ps.setInt(3, book.getBqty());
			ps.setInt(4,book.getBid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from book"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getInt(4));  
			con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
	}

	public void show() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from book");  
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getInt(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
	}

}
