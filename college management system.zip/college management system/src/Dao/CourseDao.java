package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Course;

public class CourseDao {
	int cid;

	public void showlist() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from course");  
			if(rs.next())  
		
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
		
		
	}

	public void add(Course course) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("insert into course values(?,?,?)");
			ps.setInt(1,course.getCid());
			ps.setString(2,course.getCname());
			ps.setInt(3,course.getFees());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from course"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
		
	}

	public void delete(Course course) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("delete from course where cid=(?)");
			ps.setInt(1,course.getCid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from course"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getString(4));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void update(Course course) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("update course set cname=(?), fees=(?) where cid=(?)");
			ps.setInt(1,course.getCid());
			ps.setString(2, course.getCname());
			ps.setInt(3, course.getFees());
			
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from course"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
			con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
		
		
	}

	

	
	
}
