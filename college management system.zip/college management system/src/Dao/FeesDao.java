package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Fees;

public class FeesDao {
	int due,cid;
	static int pending;

	public void insert(Fees fees) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("insert into fees values(?,?,?,?,?,?,?)");
			ps.setInt(1,fees.getFid());
			ps.setInt(2,fees.getStid());
			ps.setInt(3,fees.getCid());
			ps.setInt(4,fees.getDeposit());
			ps.setInt(5, fees.getPending());
			ps.setInt(6, fees.getTotal());
			ps.setInt(7, fees.getAfter_pay());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from fees"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+"  "+rs.getInt(3)+" "+rs.getInt(4)+" "+rs.getInt(5)+" "+rs.getInt(6)+" "+rs.getInt(7));  
				con.close(); 
				
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void show() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from fees");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+" "+rs.getInt(3)+" "+rs.getInt(4)+" "+rs.getInt(5)+" "+rs.getInt(6)+" "+rs.getInt(7)); 
			
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
		
	}

	

	public int getfees(int getcid) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from course where cid='"+getcid+"'");  
			while(rs.next())  
				due=rs.getInt(3);
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
		return due;
		
	}

	public int pending(int stid) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from fees where stid='"+stid+"'");  
			if(rs.next())  
			//System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+" "+rs.getInt(3)+" "+rs.getInt(4)+" "+rs.getInt(5)+" "+rs.getInt(6)); 
			due=rs.getInt(5);
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		return due;
	}

	public static int update(Fees fees) {
		
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("update fees set fid=(?),stid=(?),cid=(?),deposit=(?),pending=(?),total=(?),after_pay=(?) where fid='"+fees.getCid()+"'");
			ps.setInt(1, fees.getFid());
			ps.setInt(2, fees.getStid());
			ps.setInt(3, fees.getCid());
			ps.setInt(4, fees.getDeposit());
			ps.setInt(5, fees.getPending());
			ps.setInt(6, fees.getTotal());
			ps.setInt(7, fees.getAfter_pay());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from fees"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+"  "+rs.getInt(3)+" "+rs.getInt(4)+" "+rs.getInt(5)+" "+rs.getInt(6)+" "+rs.getInt(7));  
			 pending=rs.getInt(5);
				con.close(); 
				
		 
		}catch(Exception e){ System.out.println(e);}
		return pending;
	}

}
