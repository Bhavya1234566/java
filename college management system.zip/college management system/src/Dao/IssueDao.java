package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import bean.IssueBook;

public class IssueDao {

    public void issueBook(IssueBook books) {
        try {
           
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
            PreparedStatement ps = con.prepareStatement("insert into issuebook values(?,?,?,?,?)"); 
            ps.setInt(1, books.getId());
            ps.setInt(2, books.getBid());
            ps.setInt(3, books.getStid());
            ps.setDate(4, new Date(books.getDate().getTime()));
            ps.setInt(5, books.getQty());     
            ps.executeUpdate();    
            ResultSet rs = ps.executeQuery("select * from issuebook");       
            while(rs.next())  
                System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+"  "+rs.getInt(3)+" "+rs.getDate(4)+" "+rs.getInt(5));  
            con.close(); 
        } catch (Exception e) {
            System.out.println(e);
        }
    }

	public static void show() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from issuebook");  
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getInt(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
	}
}

