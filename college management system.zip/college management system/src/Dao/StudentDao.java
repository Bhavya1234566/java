package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Student;

public class StudentDao {
	static int cid;

	public void showlist() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from student");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		
		
	}

	public boolean login(Student student) {
		boolean b=false;
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from student where stid='"+student.getStid()+"'"); 
			
				if(rs.next())  
				{b=true;
					System.out.println("login successfully");  
				}
				else{
					b=false;
				}
					con.close(); 
			
			 
			}catch(Exception e){ System.out.println(e);}  
		return b;
	}

	public void add(Student student) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?)");
			ps.setInt(1,student.getStid());
			ps.setString(2,student.getStname());
			ps.setInt(3,student.getCid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from student"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void delete(Student student) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("delete from student where stid=(?)");
			ps.setInt(1,student.getStid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from student"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void update(Student student) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("update student set stname=(?), cid=(?) where stid=(?)");
			ps.setString(1, student.getStname());
			ps.setInt(2, student.getCid());
			ps.setInt(3,student.getStid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from student"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
		
		
	}

	public int cid(int stid) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from student where stid='"+stid+"'");  
			while(rs.next())  
			cid=rs.getInt(3);
				con.close(); 
		
		 
		}catch(Exception e){ System.out.println(e);} 
		return cid; 
		
	}

}
