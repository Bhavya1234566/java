package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import bean.DueFees;
import bean.Fees;

public class DueFeesDao {
int dues,stid;
Scanner sc=new Scanner(System.in);
	public void add(int pending) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			System.out.println("enter id");
			stid=sc.nextInt();
			PreparedStatement ps=con.prepareStatement("insert into duefees values(?,?)");
			ps.setInt(1, stid);
			ps.setInt(2, pending);
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from duefees"); 
			
			while(rs.next())  
				System.out.println("stid="+rs.getInt(1)+" pending= "+rs.getInt(2));
			
				con.close(); 
				
		 
		}catch(Exception e){ System.out.println(e);}
		
		
	}
	
	public int update(int change) {
		int stid,rem = 0;
		Scanner scanner=new Scanner(System.in);
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement();
			System.out.println("enter stid");
			stid=scanner.nextInt();
			int i=stmt.executeUpdate("update duefees set duependingfees='"+change+"' where stid='"+stid+"'");
			ResultSet rs=stmt.executeQuery("select * from duefees");  
			if(rs.next())  
			//System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+" "+rs.getInt(3)+" "+rs.getInt(4)+" "+rs.getInt(5)+" "+rs.getInt(6));
				rem=rs.getInt(2);
				System.out.println("done changes");
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
		return rem;
	}

	public int show(int stid2) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from duefees where stid='"+stid2+"'");  
			if(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getInt(2)); 
			dues=rs.getInt(2);
			con.close();  
			}catch(Exception e){ System.out.println(e);}
		return dues ; 
	}

	public void addchange(int dues2) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management_system","root","root");
			PreparedStatement ps=con.prepareStatement("update duefees set duependingfees=(?)");
			ps.setInt(1, dues2);
			ps.executeUpdate();
				con.close(); 
				
		 
		}catch(Exception e){ System.out.println(e);}
		
		
		
	}
	

}
