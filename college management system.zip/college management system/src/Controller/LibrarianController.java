package Controller;

import java.util.Scanner;

import Dao.LibrarianDao;
import bean.Librarian;
import opertion.LibraryOpertion;

public class LibrarianController {
	int lid,pwd;
	String lname,email;
	Scanner sc=new Scanner(System.in);
	public void add() {
		System.out.println("enter id & name& pwd& email");
		lid=sc.nextInt();
		lname=sc.next();
		pwd=sc.nextInt();
		email=sc.next();
		Librarian librarian=new Librarian();
		librarian.setLid(lid);
		librarian.setLname(lname);
		librarian.setPwd(pwd);
		librarian.setEmail(email);
		LibrarianDao dao=new LibrarianDao();
		dao.add(librarian);
	}
	public void delete() {
		System.out.println("enter id for delete");
		lid=sc.nextInt();
		Librarian librarian=new Librarian();
		librarian.setLid(lid);
		LibrarianDao dao=new LibrarianDao();
		dao.delete(librarian);
		
	}
	public void update() {
		System.out.println("enter id for update");
		lid=sc.nextInt();
		System.out.println("enter name & pwd & email which you want to update");
		lname=sc.next();
		pwd=sc.nextInt();
		email=sc.next();
		Librarian librarian=new Librarian();
		librarian.setLid(lid);
		librarian.setLname(lname);
		librarian.setPwd(pwd);
		librarian.setEmail(email);
		LibrarianDao dao=new LibrarianDao();
		dao.update(librarian);
	}
	public void show() {
		
		LibrarianDao dao=new LibrarianDao();
		dao.show();
		
		
	}
	public void login() {
		System.out.println("enter id & pwd  for login");
		lid=sc.nextInt();
		pwd=sc.nextInt();
		Librarian librarian=new Librarian();
		librarian.setLid(lid);
		librarian.setPwd(pwd);
		LibrarianDao dao=new LibrarianDao();
		boolean b=dao.login(librarian);
		if(b){
			LibraryOpertion libraryOpertion=new LibraryOpertion();
			libraryOpertion.process();	
	}
	
	

	}
}
