package Controller;

import java.util.Scanner;

import Dao.CourseDao;

import bean.Course;

public class CourseController {
	int cid,fees,stid;
	String cname;
	Scanner sc=new Scanner(System.in);
	Course course=new Course();
	CourseDao courseDao=new CourseDao();
	
	public void add() {
		
		System.out.println("enter cid,cname,fees");
		cid=sc.nextInt();
		cname=sc.next();
		fees=sc.nextInt();
		course.setCid(cid);
		course.setCname(cname);
		course.setFees(fees);
		courseDao.add(course);
	}
	public void delete() {
		System.out.println("enter id");
		cid=sc.nextInt();
		course.setCid(cid);
		courseDao.delete(course);
		
	}
	public void update() {
		System.out.println("enter cid");
		cid=sc.nextInt();
		System.out.println("enter cname,fees which want to update");
		cname=sc.next();
		fees=sc.nextInt();
		course.setCid(cid);
		course.setCname(cname);
		course.setFees(fees);
		courseDao.update(course);
		
	}
	public void showlist() {
		courseDao.showlist();
		
	}
	

}
