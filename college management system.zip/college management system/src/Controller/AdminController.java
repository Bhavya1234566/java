package Controller;

import java.util.Scanner;

import Dao.AdminDao;
import bean.Admin;
import opertion.AdminOperation;

public class AdminController {
	int adid;
	String pwd;
	Scanner sc=new Scanner(System.in);
	public void login() {
		System.out.println("enter id & pwd for login");
		adid=sc.nextInt();
		pwd=sc.next();
		Admin admin=new Admin();
		admin.setAdid(adid);
		admin.setPwd(pwd);
		AdminDao adminDao=new AdminDao();
		boolean b=adminDao.login(admin);
		if(b){
			
			AdminOperation adminOperation=new AdminOperation();
			adminOperation.process();
		}
	}

}
