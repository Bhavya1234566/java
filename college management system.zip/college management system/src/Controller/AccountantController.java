package Controller;

import java.util.Scanner;

import Dao.AccountantDao;
import bean.Accountant;
import opertion.AccountOpertion;

public class AccountantController {
	int aid,pwd;
	String aname,email;
	Scanner sc=new Scanner(System.in);
	Accountant accountant=new Accountant();
	AccountantDao accountantDao=new AccountantDao();
	public void add() {
		System.out.println("enter id & name& pwd& email");
		aid=sc.nextInt();
		aname=sc.next();
		pwd=sc.nextInt();
		email=sc.next();	
		accountant.setAid(aid);
		accountant.setAname(aname);
		accountant.setPwd(pwd);
		accountant.setEmail(email);
		accountantDao.add(accountant);
		
	}
	public void delete() {
		System.out.println("enter id to delete");
		aid=sc.nextInt();
		accountant.setAid(aid);
		accountantDao.delete(accountant);
		
	}
	public void update() {
		System.out.println("enter id which you want to update");
		aid=sc.nextInt();
		System.out.println("enter name & pwd & email");
		aname=sc.next();
		pwd=sc.nextInt();
		email=sc.next();	
		accountant.setAid(aid);
		accountant.setAname(aname);
		accountant.setPwd(pwd);
		accountant.setEmail(email);
		accountantDao.update(accountant);
		
	}
	public void show() {
		accountantDao.show();
		
	}
	public void login() {
		System.out.println("enter id & pwd");
		aid=sc.nextInt();
		pwd=sc.nextInt();
		accountant.setAid(aid);
		accountant.setPwd(pwd);
		boolean b=accountantDao.login(accountant);
		if(b){
			AccountOpertion accountOpertion=new AccountOpertion();
			accountOpertion.process();
		}
	}
	

}
