package Controller;

import java.util.Scanner;

import Dao.BookDao;
import bean.Book;

public class BookController {
	int bid,bqty,price;
	String bname;
	Scanner sc=new Scanner(System.in);
	Book book=new Book();
	BookDao bookDao=new BookDao();
	public void add() {
		bookDao.show();
		System.out.println("enter bid & bname & price & bqty");
		bid=sc.nextInt();
		bname=sc.next();
		price=sc.nextInt();
		bqty=sc.nextInt();
		book.setBid(bid);
		book.setBname(bname);
		book.setPrice(price);
		book.setBqty(bqty);
		bookDao.add(book);
		
	}
	public void delete() {
		System.out.println("enter bid");
		bid=sc.nextInt();
		book.setBid(bid);
		bookDao.delete(book);
		
	}
	public void update() {
		System.out.println("enter bid");
		bid=sc.nextInt();
		System.out.println("enter bname & price &qty which u want to update");
		bname=sc.next();
		price=sc.nextInt();
		bqty=sc.nextInt();
		book.setBid(bid);
		book.setBname(bname);
		book.setPrice(price);
		book.setBqty(bqty);
		bookDao.update(book);
		
	}
	public void show() {
		bookDao.show();
		
	}

}
