package Controller;

import java.util.Scanner;

import Dao.DueFeesDao;
import Dao.FeesDao;
import Dao.StudentDao;
import bean.DueFees;
import bean.Fees;

public class FeesController {
	static int fid,fee,dues;
	static int change;
	static int stid;
	static int cid;
	static int deposit;
	static int pending;
	static int total,after_pay;
	static int x;
	static Scanner sc=new Scanner(System.in);
	static Fees fees=new Fees();
	 static DueFees dueFees=new DueFees();
	static FeesDao dao=new FeesDao();
	static DueFeesDao dueFeesDao=new DueFeesDao();
	public static void insert(int getcid){
		System.out.println("enter fid,stid,cid,deposit,total");
		fid=sc.nextInt();
		stid=sc.nextInt();
		deposit=sc.nextInt();
		fee=dao.getfees(getcid);
		total=fee;
		pending=total-deposit;
		fees.setFid(fid);
		fees.setStid(stid);
		fees.setCid(getcid);
		fees.setDeposit(deposit);
		fees.setPending(pending);
		fees.setTotal(total);
		dao.insert(fees);
		dueFeesDao.add(pending);
		
	}
	public static void show(){
		dao.show();
		
	}
	public static void pending(){
		System.out.println("enter id");
		stid=sc.nextInt();
		dues=dueFeesDao.show(stid);
		dueFeesDao.addchange(dues);
			System.out.println("do u want to pay");
			x=sc.nextInt();
			if(x==1){
				System.out.println("enter fid,stid,deposit");
				fid=sc.nextInt();
				stid=sc.nextInt();
				deposit=sc.nextInt();
				StudentDao studentDao=new StudentDao();
				cid=studentDao.cid(stid);
				after_pay=dues;
				pending=after_pay-deposit;
				fees.setFid(fid);
				fees.setStid(stid);
				fees.setCid(cid);
				fees.setDeposit(deposit);
				fees.setPending(pending);
				fees.setAfter_pay(after_pay);
				change=FeesDao.update(fees);
				int rem=dueFeesDao.update(change);
				if(pending==0){
					System.out.println("done all payments");
				}
		}
		
		
	}
}
