package Controller;

import java.util.Scanner;

import Dao.StudentDao;
import bean.Student;

public class StudentController {
	int stid,cid;
	String stname;
	Scanner sc=new Scanner(System.in);
	Student student=new Student();
	StudentDao studentDao=new StudentDao();
	public void login() {
		System.out.println("enter id");
		stid=sc.nextInt();
		student.setStid(stid);
		boolean b=studentDao.login(student);
		if(b){
			StudentDao studentDao=new StudentDao();
			studentDao.showlist();
		}
	}
	public void add() {
		System.out.println("enter stid,stname,cid");
		stid=sc.nextInt();
		stname=sc.next();
		cid=sc.nextInt();
		student.setStid(stid);
		student.setStname(stname);
		student.setCid(cid);
		studentDao.add(student);
		
	}
	public void delete() {
		System.out.println("enter stid");
		stid=sc.nextInt();
		student.setStid(stid);
		studentDao.delete(student);
		
		
	}
	public void update() {
		System.out.println("enter stid");
		stid=sc.nextInt();
		System.out.println("enter stname,cid");
		stname=sc.next();
		cid=sc.nextInt();
		student.setStid(stid);
		student.setStname(stname);
		student.setCid(cid);
		studentDao.update(student);
		
	}
	public void show() {
		studentDao.showlist();
		
	}
	public void getcid(){
		FeesController.show();
		System.out.println("enter id");
		stid=sc.nextInt();
		int getcid=studentDao.cid(stid);
		FeesController.insert(getcid);
	}
	

}
