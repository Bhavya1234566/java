package Controller;


import java.util.Date;
import java.util.Scanner;

import Dao.BookDao;
import Dao.IssueDao;
import bean.IssueBook;

public class IssueBookController {
	int id,bid,stid,qty;
	Date date=new Date();
	Scanner sc=new Scanner(System.in);
	IssueBook books=new IssueBook();
	public void issueBook() {
		IssueDao.show();
		System.out.println("enter id& bid& stid &qty &date");
		id=sc.nextInt();
		bid=sc.nextInt();
		stid=sc.nextInt();
		qty=sc.nextInt();
		date=date;
		books.setId(id);
		books.setBid(bid);
		books.setStid(stid);
		books.setDate(date);
		books.setQty(qty);
		IssueDao issueDao=new IssueDao();
		issueDao.issueBook(books);
		
		
		
		
	}

}
