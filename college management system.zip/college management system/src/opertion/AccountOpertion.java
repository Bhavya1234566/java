package opertion;

import java.util.Scanner;

public class AccountOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("press 1 for course/n press 2 for student/n enter choice");
		ch=sc.nextInt();
		if(ch==1){
			CourseOpertion courseOpertion=new CourseOpertion();
			courseOpertion.process();
		}
		else if(ch==2){
			StudentOpertion studentOpertion=new StudentOpertion();
			studentOpertion.process();
		}
		else{
			System.out.println("wrong");
		}
	}

}
