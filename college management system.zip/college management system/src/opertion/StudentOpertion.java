package opertion;

import java.util.Scanner;

import Controller.FeesController;
import Controller.StudentController;

public class StudentOpertion {

		int ch,choice;
		Scanner sc=new Scanner(System.in);
		public void process() {
			System.out.println("press 1 for add /n press 2 for delete /n press 3 for update/n press 4 for show/n press 5 for fees/n enter choice");
			ch=sc.nextInt();
			if(ch==1){
				StudentController studentController=new StudentController();
				studentController.add();
			}
			else if(ch==2){
				StudentController studentController=new StudentController();
				studentController.delete();
			}
			else if(ch==3){
				StudentController studentController=new StudentController();
				studentController.update();
			}
			else if(ch==4){
				StudentController studentController=new StudentController();
				studentController.show();
			}
			else if(ch==5){
				System.out.println("press 1 for 1st payment/n press 2 for next payment");
				choice=sc.nextInt();
				if(choice==1){
					StudentController studentController=new StudentController();
					studentController.getcid();
				}
				else if(choice==2){
					FeesController feesController=new FeesController();
					feesController.pending();
				}
				
			}
			else{
				System.out.println("wrong");
			}
			
		}
		
	

}
