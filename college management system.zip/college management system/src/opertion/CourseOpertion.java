package opertion;

import java.util.Scanner;

import Controller.CourseController;

public class CourseOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("press 1 for add /n press 2 for delete /n press 3 for update/n press 4 for show/n enter choice");
		ch=sc.nextInt();
		if(ch==1){
			CourseController courseController=new CourseController();
			courseController.add();
		}
		else if(ch==2){
			CourseController courseController=new CourseController();
			courseController.delete();
		}
		else if(ch==3){
			CourseController courseController=new CourseController();
			courseController.update();
		}
		else if(ch==4){
			CourseController courseController=new CourseController();
			courseController.showlist();
		}
		else{
			System.out.println("wrong");
		}
		
	}

}
