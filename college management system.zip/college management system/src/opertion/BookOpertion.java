package opertion;

import java.util.Scanner;

import Controller.BookController;

public class BookOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);

	public void process() {
		System.out.println("press 1 for add /n press 2 for delete/n press 3 for update /n press 4 for show/n enter choice");
		ch=sc.nextInt();
		if(ch==1){
			BookController bookController=new BookController();
			bookController.add();
		}
		else if(ch==2){
			BookController bookController=new BookController();
			bookController.delete();
		}
		else if(ch==3){
			BookController bookController=new BookController();
			bookController.update();
		}
		else if(ch==4){
			BookController bookController=new BookController();
			bookController.show();
		}
		else{
			System.out.println("wrong");
		}
	}

}
