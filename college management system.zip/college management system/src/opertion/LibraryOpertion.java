package opertion;

import java.util.Scanner;

import Controller.IssueBookController;


public class LibraryOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("press 1 for books /n press 2 for studentIssueBook /n enter choice");
		ch=sc.nextInt();
		if(ch==1){
			BookOpertion bookOpertion=new BookOpertion();
			bookOpertion.process();
		}
		else if(ch==2){
			IssueBookController issueBookController=new IssueBookController();
			issueBookController.issueBook();
		}
		else{
			System.out.println("wrong");
		}
	
		
	}

}
