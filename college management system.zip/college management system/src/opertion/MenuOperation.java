package opertion;

import java.util.Scanner;

import Controller.AccountantController;
import Controller.AdminController;
import Controller.LibrarianController;
import Controller.StudentController;

public class MenuOperation {
	int ch,x;
	Scanner sc=new Scanner(System.in);
	public void process(){
		do{
		System.out.println("press 1 for Admin /n press 2 for librarian /n press 3 for student /n press 4 for Accountant");
		ch=sc.nextInt();
		if(ch==1){
			AdminController adminController=new AdminController();
			adminController.login();
		}
		else if(ch==2){
			LibrarianController controller=new LibrarianController();
			controller.login();
		}
		else if(ch==3){
			StudentController studentController=new StudentController();
			studentController.login();
		}
		else if(ch==4){
			AccountantController accountantController=new AccountantController();
			accountantController.login();
		}
		else{
			System.out.println("wrong");
		}
		System.out.println("do you want to continue");
		x=sc.nextInt();
		}while(x==1);
	}
}
