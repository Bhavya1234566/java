package opertion;

import java.util.Scanner;

import Dao.CourseDao;
import Dao.StudentDao;

public class AdminOperation {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("press 1 for librarian /n press 2 for accountant /n press 3 for student /n press 4 for course /n enter choice");
		ch=sc.nextInt();
		if(ch==1){
			LibrarianOperation librarianOperation=new LibrarianOperation();
			librarianOperation.process();
		}
		else if(ch==2){
			AccountantOperation accountantOperation=new AccountantOperation();
			accountantOperation.process();
		}
		else if(ch==3){
			StudentDao dao=new StudentDao();
			dao.showlist();
		}
		else if(ch==4){
			CourseDao courseDao=new CourseDao();
			courseDao.showlist();
		}
		else{
			System.out.println("wrong");
		}
		
	}

}
