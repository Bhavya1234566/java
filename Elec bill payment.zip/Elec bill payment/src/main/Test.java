package main;

import opertion.Menu;

public class Test {
	public static void main(String[] args) {
		Menu menu=new Menu();
		menu.process();
	}

}
