package controller;

import java.util.Scanner;

import Dao.BillDao;
import bean.Bill;

public class BillController {
	int id,deposit,pending;
	String email;
	Scanner sc=new Scanner(System.in);
	public void bill(){
		System.out.println("enter id,email,deposit,pending");
		id=sc.nextInt();
		email=sc.next();
		deposit=sc.nextInt();
		pending=sc.nextInt();
		Bill bill=new Bill();
		bill.setId(id);
		bill.setEmail(email);
		bill.setDeposit(deposit);
		bill.setPending(pending);
		BillDao billDao=new BillDao();
		billDao.bill(bill);
	}

}
