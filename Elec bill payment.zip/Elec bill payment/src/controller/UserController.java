package controller;

import java.util.Scanner;

import Dao.UserDao;
import bean.User;

public class UserController {
	int id,bill,s,remain;
	String name,email;
	Scanner sc=new Scanner(System.in);
	public void insert(){
		System.out.println("enter id,name,email,bill");
		id=sc.nextInt();
		name=sc.next();
		email=sc.next();
		bill=sc.nextInt();
		User user=new User();
		user.setId(id);
		user.setName(name);
		user.setEmail(email);
		user.setBill(bill);
		UserDao dao=new UserDao();
		dao.insert(user);
	}
	public void delete() {
		System.out.println("enter id:");
		id=sc.nextInt();
		User user=new User();
		user.setId(id);
		UserDao dao=new UserDao();
		dao.delete(user);
		
	}
	public void update() {
		System.out.println("enter id:");
		id=sc.nextInt();
		User user=new User();
		user.setId(id);
		UserDao dao=new UserDao();
		dao.update(user);
	}
	public void select() {
		System.out.println("enter email:");
		email=sc.next();
		User user=new User();
		user.setEmail(email);
		UserDao dao=new UserDao();
		int i=dao.select(user);
		System.out.println("your pending bill:"+i);
		System.out.println("enter payment:");
		s=sc.nextInt();
		remain=i-s;
		System.out.println("your remaining bill is:"+remain);
	
	}
	

}
