package controller;

import java.util.Scanner;

import Dao.AdminDao;
import bean.Admin;
import opertion.UserOpertion;

public class AdminController {
	int id,pwd;
	Scanner sc=new Scanner(System.in);
	public void login(){
		System.out.println("enter id & pwd:");
		id=sc.nextInt();
		pwd=sc.nextInt();
		Admin a=new Admin();
		a.setId(id);
		a.setPwd(pwd);
		AdminDao adminDao=new AdminDao();
		boolean b=adminDao.login(a);
		if(b){
			System.out.println("write");
			UserOpertion opertion=new UserOpertion();
			opertion.choice();
			BillController billController=new BillController();
			billController.bill();
		}
		else{
			System.out.println("wrong");
		}
	}

}
