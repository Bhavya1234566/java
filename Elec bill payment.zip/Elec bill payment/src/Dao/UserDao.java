package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.User;

public class UserDao {
	int i;

	public void insert(User user) {
		
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/users_bill","root","root");  
		Statement stmt=con.createStatement(); 
		
		i=stmt.executeUpdate("insert into billofuser values('"+user.getId()+"','"+user.getName()+"','"+user.getEmail()+"',+'"+user.getBill()+"') ");
		
		ResultSet rs=stmt.executeQuery("select * from billofuser");  
		while(rs.next())  
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getInt(4));  
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void delete(User user) {
		

		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/users_bill","root","root");  
		Statement stmt=con.createStatement(); 
		
		i=stmt.executeUpdate("delete from billofuser where id='"+user.getId()+"'");
		
		ResultSet rs=stmt.executeQuery("select * from billofuser");  
		while(rs.next())  
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getInt(4));  
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		
	}

	public void update(User user) {
		
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/users_bill","root","root");  
			Statement stmt=con.createStatement(); 
			
			i=stmt.executeUpdate("update billofuser set id='"+user.getId()+"'");
			
			ResultSet rs=stmt.executeQuery("select * from billofuser");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getInt(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
			
	}

	public int select(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/users_bill","root","root");  
			Statement stmt=con.createStatement(); 
			
			
			
			ResultSet rs=stmt.executeQuery("select * from billofuser where email='"+user.getEmail()+"'");  
			if(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getInt(4));  
			i=rs.getInt(4);
			
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
			
		return i;
	}
	

}
