package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Admin;

public class AdminDao {
	
	boolean b=false;
	public boolean login(Admin a){
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Admin","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from login where id='"+a.getId()+"'and pwd='"+a.getPwd()+"'"); 
			
				if(rs.next())  
				{b=true;
					System.out.println("login successfully");  
				}
				else{
					b=false;
				}
					con.close(); 
			
			 
			}catch(Exception e){ System.out.println(e);}  
		return b;
			
	}

}
