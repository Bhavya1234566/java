package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Bill;

public class BillDao {
	int i;
	public void bill(Bill bill) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/elec_bill","root","root");  
			Statement stmt=con.createStatement(); 
			
			i=stmt.executeUpdate("insert into payment values('"+bill.getId()+"','"+bill.getEmail()+"','"+bill.getDeposit()+"','"+bill.getPending()+"') ");
			
			ResultSet rs=stmt.executeQuery("select * from payment");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getInt(4));  
			con.close();  
			}catch(Exception e){ System.out.println(e);}  
		
	}

}
