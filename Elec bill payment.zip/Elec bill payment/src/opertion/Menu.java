package opertion;

import java.util.Scanner;

import controller.AdminController;

public class Menu {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process(){
		System.out.println("press 1 for admin/n press 2 for user/n enter choice:");
		ch=sc.nextInt();
		if(ch==1){
			AdminController adminController=new AdminController();
			adminController.login();
		}
		else if(ch==2){
			UserOpertion opertion=new UserOpertion();
			opertion.choice();
		}
	}

}
