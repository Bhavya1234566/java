package opertion;

import java.util.Scanner;

import controller.UserController;

public class UserOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void choice(){
		System.out.println("press 1 for insert/n press 2 for delete/n press 3 for update/n press 4 for select/n enter choice:");
		ch=sc.nextInt();
		if(ch==1){
			UserController controller=new UserController();
			controller.insert();
		}
		else if(ch==2){
			UserController controller=new UserController();
			controller.delete();
		}
		else if(ch==3){
			UserController controller=new UserController();
			controller.update();
		}
		else if(ch==4){
			UserController controller=new UserController();
			controller.select();
		}
	}

}
