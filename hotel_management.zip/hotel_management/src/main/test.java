package main;

import operation.HotelEntryOperation;

public class test {

	public static void main(String[] args) {
		HotelEntryOperation hotelEntryOperation=new HotelEntryOperation();
		hotelEntryOperation.process();		
	}
}
