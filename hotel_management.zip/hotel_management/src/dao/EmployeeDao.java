package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Employee;

public class EmployeeDao {

	public void add(Employee emp) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("insert into employee values(default,?,?)");
			ps.setString(1,emp.getEname());
			ps.setInt(2, emp.getEtid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from employee"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
				
				
				con.close(); 
		
		 
		}catch(Exception e){ e.printStackTrace();}  
		
	}

	public void delete(Employee emp) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("delete from employee where etid=(?)");
			ps.setInt(1, emp.getEtid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from employee"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
				
				
				con.close(); 
		
		 
		}catch(Exception e){ e.printStackTrace();}
		
	}

	public void update(Employee emp) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("update employee set ename=(?) where etid=(?)");
			ps.setString(1, emp.getEname());
			ps.setInt(2, emp.getEtid());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from employee"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
				
				
				con.close(); 
		
		 
		}catch(Exception e){ e.printStackTrace();}
		
	}

	public void show() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from employee");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){  e.printStackTrace();} 
		
	}
	

}
