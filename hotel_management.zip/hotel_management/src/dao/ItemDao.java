package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Item;

public class ItemDao {
	int price;
	public void insert(Item item) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("insert into item values(default,?,?,?)");
			ps.setString(1,item.getItem_name());
			ps.setInt(2, item.getItem_price());
			ps.setInt(3, item.getItem_id());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from item"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getInt(4));  
				
				
				con.close(); 
		
		 
		}catch(Exception e){ e.printStackTrace();}  
		
	}

	public void delete(Item item) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("delete from item where id=(?)");
			ps.setInt(1,item.getId());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from item"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
				
				
				con.close(); 
		
		 
		}catch(Exception e){ e.printStackTrace();}
		
	}

	public void update(Item item) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("update item set item_price=(?) where id=(?)");
			ps.setInt(1, item.getItem_price());
			ps.setInt(2,item.getId());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from item"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
				
				
				con.close(); 
		
		 
		}catch(Exception e){ e.printStackTrace();}
	}

	public void showadmin() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from item");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3));  
			con.close();  
			}catch(Exception e){  e.printStackTrace();} 
		
	}

	public int showuser(int choice) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from item where id='"+choice+"'");  
			if(rs.next())  
			System.out.println("price is:"+rs.getInt(3));
			price=rs.getInt(3);
			con.close();  
			}catch(Exception e){  e.printStackTrace();} 
		return price;
		
	}

}
