package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import bean.User;

public class UserDao {
	boolean b=false;
	public void show() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from user");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2));  
			con.close();  
			}catch(Exception e){  e.printStackTrace();} 
		
	}

	public boolean login(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from user where id='"+user.getId()+"'and pwd='"+user.getPwd()+"'"); 
			
				if(rs.next())  
				{b=true;
					System.out.println("login successfully");  
				}
				else{
					b=false;
				}
					con.close(); 
			
			 
			}catch(Exception e){ 
				e.printStackTrace();;} 
		return b;
	}

	public void register(User user) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("insert into user values(?,?)");
			ps.setInt(1,user.getId());
			ps.setString(2,user.getPwd());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from user"); 
			
			while(rs.next())  
				System.out.println("successfully registered");  
				con.close();  
		}catch(Exception e){ e.printStackTrace();}  
		
	}

	public void forget_pwd(User user) {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from user where id='"+user.getId()+"'"); 
			
				while(rs.next())  
					System.out.println("passward is:"+rs.getString(2));
					con.close(); 
			
			 
			}catch(Exception e){ 
				e.printStackTrace();;} 
	}

	public void change_pwd(User user) {
		
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("update user set pwd=(?) where id=(?)");
			ps.setString(1, user.getPwd());
			ps.setInt(2, user.getId());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from user"); 
			
			if(rs.next())  
				System.out.println("pwd reset");  
				con.close(); 
		}catch(Exception e){ e.printStackTrace();}
		
	}

}
