package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.Employeetype;

public class EmployeetypeDao {
	

	public void insert(Employeetype employee) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("insert into emp_type values(default,?)");
			ps.setString(2,employee.getEmptype());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from emp_type"); 
			
			while(rs.next())  {
				System.out.println(rs.getInt(1)+"  "+rs.getString(2));  
			}
				
				con.close(); 
		
		 
		}catch(Exception e){  e.printStackTrace();}  
	}

	public void show() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from emp_type");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2));  
			con.close();  
			}catch(Exception e){  e.printStackTrace();} 
		
	}

}

