package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Category;
import bean.List;

public class CategoryDao {
	int p;
	public void insert(Category category1) {
		try{
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");
			PreparedStatement ps=con.prepareStatement("insert into menu values(default,?)");
			ps.setString(1, category1.getCategory());
			ps.executeUpdate();
			ResultSet rs=ps.executeQuery("select * from menu"); 
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2));  
		
				
				con.close(); 
		
		 
		}catch(Exception e){  e.printStackTrace();}  
		
	}

	public void show() {
		
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from menu");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2));  
			con.close();  
			}catch(Exception e){  e.printStackTrace();} 
		
	}

	public int check(int id) {
		
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management","root","root");  
			Statement stmt=con.createStatement(); 
			ResultSet rs=stmt.executeQuery("select * from item where item_id='"+id+"'");  
			while(rs.next()) {
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getInt(3)); 
				p=rs.getInt(1);
			}
			 
			con.close();  
			}catch(Exception e){  e.printStackTrace();} 
		return p;
		
	}

	
		
	}

	   

	