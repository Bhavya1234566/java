package operation;

import java.util.Scanner;

import controller.UserController;

public class AdminOpertion {
	int ch,x;
	Scanner sc=new Scanner(System.in);
	public void process() {
		do{
		System.out.println("press 1 for employee /n press 2 for category /n press 3 for user_display");
		ch=sc.nextInt();
		if(ch==1){
			Employee_typeOpertion employee_typeOpertion=new Employee_typeOpertion();
			employee_typeOpertion.process();
		}
		else if(ch==2){
			CategoryOpertion categoryOpertion=new CategoryOpertion();
			categoryOpertion.process();
		}
		else if(ch==3){
			UserController controller=new UserController();
			controller.show();
		}
		else{
			System.out.println("wrong");
		}
		System.out.println("do u want to continue");
		x=sc.nextInt();
		}while(x==1);
	}

}
