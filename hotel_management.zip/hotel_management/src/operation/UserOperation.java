package operation;

import java.util.Scanner;

import controller.UserController;

public class UserOperation {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process(){
		System.out.println("press 1 for login /n press 2 for registration /n press 3 for forget pwd /n press 4 for change pwd");
		ch=sc.nextInt();
		if(ch==1){
			UserController userController=new UserController();
			userController.login();
		}
		else if(ch==2){
			UserController controller=new UserController();
			controller.registeration();
		}
		else if(ch==3){
			UserController controller=new UserController();
			controller.forget_pwd();
		}
		else if(ch==4){
			UserController controller=new UserController();
			controller.change_pwd();
		}
		else {
			System.out.println("wrong");
		}
	}
}
