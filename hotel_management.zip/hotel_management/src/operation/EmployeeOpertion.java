package operation;

import java.util.Scanner;

import controller.EmployeeController;

public class EmployeeOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("press 1 for insert /n press 2 for delete /n press 3 for update /n press 4 for show");
		ch=sc.nextInt();
		if(ch==1){
			EmployeeController employeeController=new EmployeeController();
			employeeController.insert();
		}
		else if(ch==2){
			EmployeeController employeeController=new EmployeeController();
			employeeController.delete();
		}
		else if(ch==3){
			EmployeeController employeeController=new EmployeeController();
			employeeController.update();
		}
		else if(ch==4){
			EmployeeController employeeController=new EmployeeController();
			employeeController.show();
		}
		
	}

}
