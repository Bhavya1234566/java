package operation;

import java.util.Scanner;

import controller.EmployeetypeController;

public class Employee_typeOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process(){
		System.out.println("press 1 for insert types /n press 2 for show types");
		ch=sc.nextInt();
		if(ch==1){
		EmployeetypeController controller=new EmployeetypeController();
		controller.insert();
		}
		else if(ch==2){
			EmployeetypeController employeetypeController=new EmployeetypeController();
			employeetypeController.show();
		}
	}

}
