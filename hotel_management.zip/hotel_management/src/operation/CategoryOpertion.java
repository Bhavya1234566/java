package operation;

import java.util.Scanner;

import controller.CategoryController;

public class CategoryOpertion {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("press 1 for insert /n press 2 for show");
		ch=sc.nextInt();
		if(ch==1){
			CategoryController categoryController=new CategoryController();
			categoryController.insert();
		}
		else if(ch==2){
			CategoryController categoryController=new CategoryController();
			categoryController.showadmin();
		}
		
	}

}
