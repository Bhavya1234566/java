package operation;

import java.util.Scanner;

import controller.EmployeeController;
import controller.ItemController;

public class ItemOperation {
	int ch;
	Scanner sc=new Scanner(System.in);
	public void process() {
		System.out.println("press 1 for insert /n press 2 for delete /n press 3 for update /n press 4 for show");
		ch=sc.nextInt();
		if(ch==1){
			ItemController controller=new ItemController();
			controller.insert();
		}
		else if(ch==2){
			ItemController controller=new ItemController();
			controller.delete();
		}
		else if(ch==3){
			ItemController controller=new ItemController();
			controller.update();
		}
		else if(ch==4){
			ItemController controller=new ItemController();
			controller.showadmin();
		}
		else{
			System.out.println("wrong");
		
	}
		
	}

}
