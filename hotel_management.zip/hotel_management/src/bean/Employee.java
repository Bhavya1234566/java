package bean;

public class Employee {
	int eid,etid;
	String ename;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public int getEtid() {
		return etid;
	}
	public void setEtid(int etid) {
		this.etid = etid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
}
