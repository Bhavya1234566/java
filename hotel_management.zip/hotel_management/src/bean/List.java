package bean;

public class List {
	 int id;
	 int qty;
	 int price;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	 public String toString() {
	        return "Choice: " + id + ", Quantity: " + qty + ", Total: " + price;
	    }
	
	

}
