package bean;

public class Employeetype {
	int emp_type_id;
	
	
	public int getEmp_type_id() {
		return emp_type_id;
	}
	public void setEmp_type_id(int emp_type_id) {
		this.emp_type_id = emp_type_id;
	}
	
	public String getEmptype() {
		return emptype;
	}
	public void setEmptype(String emptype) {
		this.emptype = emptype;
	}
	String emptype;

}
