package controller;

import java.util.Scanner;

import bean.Item;
import dao.ItemDao;

public class ItemController {
	int id,item_price,item_id;
	String item_name;
	Scanner sc=new Scanner(System.in);
	Item item=new Item();
	ItemDao dao=new ItemDao();
	public void insert() {
		dao.showadmin();
		System.out.println("id,item_name,item_price,item_i");
		id=sc.nextInt();
		item_name=sc.next();
		item_price=sc.nextInt();
		item_id=sc.nextInt();
		item.setId(id);
		item.setItem_name(item_name);
		item.setItem_price(item_price);
		item.setItem_id(item_id);
		dao.insert(item);
		
	}

	public void delete() {
		dao.showadmin();
		System.out.println("enter id");
		id=sc.nextInt();
		item.setId(id);
		dao.delete(item);
		
	}

	public void update() {
		dao.showadmin();
		System.out.println("enter id");
		id=sc.nextInt();
		System.out.println("enter price which you want to update");
		item_price=sc.nextInt();
		item.setItem_price(item_price);
		item.setId(id);
		dao.update(item);
		
	}

	public void showadmin() {
		dao.showadmin();
	}
	public int showuser(int choice){
		int c=dao.showuser(choice);
		return c;
		
		
	}

}
