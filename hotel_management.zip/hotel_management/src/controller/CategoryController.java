package controller;

import java.util.ArrayList;
import java.util.Scanner;

import bean.Category;
import bean.List;
import dao.CategoryDao;
import dao.ItemDao;

import operation.ItemOperation;

public class CategoryController {
	int category_id,id,p,qty,total,choice,price,x,totalbill=0;
	String category,name;
	Scanner sc=new Scanner(System.in);
	Category category1=new Category();
	CategoryDao categoryDao=new CategoryDao();
	public void insert() {
		System.out.println("enter category,");
		category=sc.next();
		category1.setCategory(category);
		categoryDao.insert(category1);
	}
	public void showadmin() {
		categoryDao.show();
		ItemOperation itemOperation=new ItemOperation();
		itemOperation.process();
		
	}
	public void showuser() {
		do{
		categoryDao.show();
		System.out.println("what do u want");
		id=sc.nextInt();
		p=categoryDao.check(id);
		System.out.println("enter choice from them");
		choice=sc.nextInt();
		ItemController controller=new ItemController();
		price=controller.showuser(choice);
		System.out.println("enter qty");
		qty=sc.nextInt();
		total=qty*price;
		System.out.println("total bill is"+total);
		System.out.println("do u want more");
		x=sc.nextInt();
		totalbill=totalbill+total;
		System.out.println("total bill is:"+totalbill);
		}while(x==1);
		ArrayList<List> a = new ArrayList<List>();
		 List listItem = new List();
	        listItem.setId(id);
	        listItem.setQty(qty);
	        listItem.setPrice(totalbill);
	        a.add(listItem);
		for (List list : a) {
			System.out.println(list.getId()+" "+list.getQty()+" "+list.getPrice());
		}
	}
	
}
