package controller;

import java.util.Scanner;

import bean.Admin;
import dao.AdminDao;
import operation.AdminOpertion;
import operation.Employee_typeOpertion;

public class AdminController {
	int id;
	String pwd;
	Scanner sc=new Scanner(System.in);
	public void login() {
		System.out.println("enter id & pwd");
		id=sc.nextInt();
		pwd=sc.next();
		Admin admin=new Admin();
		admin.setId(id);
		admin.setPwd(pwd);
		AdminDao adminDao=new AdminDao();
		boolean b=adminDao.login(admin);
		if(b){
			AdminOpertion adminOpertion=new AdminOpertion();
			adminOpertion.process();
		}
		
	} 
}
