package controller;

import java.util.Scanner;

import bean.User;
import dao.UserDao;

public class UserController {
	int id;
	String pwd;
	Scanner sc=new Scanner(System.in);
	User user=new User();
	UserDao dao=new UserDao();
	public void show() {
		dao.show();
	}
	public void login() {
		System.out.println("enter id & pwd");
		id=sc.nextInt();
		pwd=sc.next();
		user.setId(id);
		user.setPwd(pwd);
		boolean b=dao.login(user);
		if(b){
			CategoryController categoryController=new CategoryController();
			categoryController.showuser();
		}
	}
	public void registeration() {
		System.out.println("enter id,pwd");
		id=sc.nextInt();
		pwd=sc.next();
		user.setId(id);
		user.setPwd(pwd);
		dao.register(user);
		
	}
	public void forget_pwd() {
		System.out.println("enter id");
		id=sc.nextInt();
		user.setId(id);
		dao.forget_pwd(user);
		
	}
	public void change_pwd() {
		System.out.println("enter id");
		id=sc.nextInt();
		System.out.println("enter pwd want to put");
		pwd=sc.next();
		user.setId(id);
		user.setPwd(pwd);
		dao.change_pwd(user);
		
	}

}
