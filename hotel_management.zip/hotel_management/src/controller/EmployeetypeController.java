package controller;

import java.util.Scanner;

import bean.Employeetype;
import dao.EmployeetypeDao;
import operation.EmployeeOpertion;


public class EmployeetypeController {
	int emp_type_id,p;
	String emptype;
	Scanner sc=new Scanner(System.in);
	EmployeetypeDao employeetypeDao=new EmployeetypeDao();
	public void insert() {
		System.out.println("enter emptype,emp_type_id");
		emp_type_id=sc.nextInt();
		emptype=sc.next();
		Employeetype employee=new Employeetype();
		employee.setEmp_type_id(emp_type_id);
		employee.setEmptype(emptype);
		employeetypeDao.insert(employee);
		
		}
	public void show() {
		employeetypeDao.show();
		EmployeeOpertion employeeOpertion=new EmployeeOpertion();
		employeeOpertion.process();
		
	}
	

}
