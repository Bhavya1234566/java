package controller;

import java.util.Scanner;

import bean.Employee;
import dao.EmployeeDao;

public class EmployeeController {
	int eid,etid;
	String ename;
	Scanner sc=new Scanner(System.in);
	Employee emp=new Employee();
	EmployeeDao dao=new EmployeeDao();
	public void insert() {
		dao.show();
		System.out.println("enter eid ,ename,etid");
		eid=sc.nextInt();
		ename=sc.next();
		etid=sc.nextInt();
		emp.setEid(eid);
		emp.setEname(ename);
		emp.setEtid(etid);
		dao.add(emp);
		
	}
	public void delete() {
		dao.show();
		System.out.println("enter etid");
		etid=sc.nextInt();
		emp.setEtid(etid);
		dao.delete(emp);
		
	}
	public void update() {
		dao.show();
		System.out.println("enter etid");
		etid=sc.nextInt();
		System.out.println("enter name which you want to update");
		ename=sc.next();
		emp.setEname(ename);
		emp.setEtid(etid);
		dao.update(emp);
		
	}
	public void show() {
		dao.show();
		
	}

}
